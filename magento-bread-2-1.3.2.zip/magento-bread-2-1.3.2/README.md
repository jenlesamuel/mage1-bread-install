# Bread Magento Extension Quick Start Guide

The Bread Magento Extension allows Magento merchants to begin offering purchase financing options for their customers in minutes, without having to integrate directly with Bread's REST APIs.

The Bread Magento Extension includes:
  - Integration as a payment method at checkout
  - Optional conversion with financing directly from the shopping cart overview page
  - Optional conversion with financing directly from product detail pages
  - Integration with back-end order management, including refunds, cancellations, and invoicing/capture.

### Getting Started
- Download the latest version of the Bread Magento Extension
- Log into the admin panel of your Magento store
- In the System menu, choose Magento Connect --> Magento Connect Manager
- Under "Direct package file upload", upload the Bread Magento Extension (which is a .tar.gz archive)
- This should install the Bread Magento Extension.  Return to the Magento admin panel and choose Configuration from the System menu, then choose Payment Methods from the bar at left. If the extension was successfully installed, you should see a section labeled "Bread Checkout"

Supply the following information to the Bread Checkout configuration fields:

Field | Type | Description | Example
-------|---------|----------|-------
**Enabled**|[Yes/No]|Globally enables or disables the Bread Checkout Extension.  When enabled, Bread appears as a payment method option at checkout|Yes
**Enabled on Product Details Page**|[Yes/No]|Displays the Bread button for conversions directly from the product details page.  Enabled must also be set to Yes|Yes
**Enabled on Cart Overview Page**|[Yes/No]|Displays the Bread button for conversions directly from the shopping cart page.  Enabled must also be set to Yes|Yes
**API URL**|[Text/URL]|The base URL for all Bread REST API requests.  Switch this between sandbox and production URLs when switching between testing and live environments|https://api-sandbox.getbread.com
**JavaScript Library Location**|[Text/URL]|The path to the Bread javascript include file.  Switch this between sandbox and production URLs when switching between testing and live environments|https://checkout-sandbox.getbread.com/bread.js
**API Public Key**|[Text]|The public merchant identifier key assigned to you by Bread for your account.  Switch this between test and live keys when switching between testing and live environments|aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa
**API Secret Key**|[Text]|The secret merchant identifier key assigned to you by Bread for your account.  Switch this between test and live keys when switching between testing and live environments|bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb
**Display as Button on Product Detail Pages When Logged In**|[Yes/No]|If set to no, when the user is logged in to Bread with an offer of credit terms, the button on product pages will be replaced by informative text displaying to the user the cost per month of the item, based on his risk-based rate and prompting him to add the item to the merchant shopping cart.  When set to yes, the cost per month is displayed in a button that can be used to check out directly with a single item from the product detail page.|No
**Bread Button Design**|[Text/CSS]|Custom CSS that defines the look and feel of the Bread button to match your storefront.  Will fail validation if not well-constructed CSS or includes any javascript events|@import url(http://fonts.googleapis.com/css?family=Open+Sans); html, body, .bread-embed {   margin: 0;   padding: 0;   overflow: hidden;   position: absolute;   top: 0;   right: 0;   bottom: 0;   left: 0;   font-family: "Open Sans", sans-serif; }  .bread-embed {   visibility: hidden; }  .bread-btn {   background: #dd0000;   font-size: 13px;   letter-spacing: 1px;   color: #fff;   cursor: pointer;   border-radius: 99999px;   margin: 0 2px 5px;   box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);   border: 1px solid rgba(255, 255, 255, 0.4); } .bread-btn:active {   -webkit-transform: translateY(1px);   box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2); } .bread-btn .bread-embed-inner {   position: absolute;   top: 0;   left: 50px;   left: 45px;   right: 0;   bottom: 0;   padding-right: 1em;   text-shadow: 0 -1px 0px rgba(0, 0, 0, 0.3); } .bread-btn .bread-embed-icon {   position: absolute;   top: 8px;   left: -50px;   bottom: 8px;   right: 100%;   margin-right: -38px; font-size:.8em;   margin-left: 60px;   background: white url("") no-repeat center;   box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);   background-size: auto 60%;   border-radius: 100%;   cursor: pointer; } .bread-btn .bread-embed-icon:after {   content: "$";   margin-top: -1px;  font-weight: bold;   font-size: 1.3em;   margin-left: 1px;   color: #dd0000;   position: absolute;   top: 50%;   left: 50%;   -webkit-transform: translate3d(-50%, -50%, 0); } .bread-btn .bread-pot {   background: url("") no-repeat center;   background-size: auto 45%;   position: absolute;   top: 0;   right: 0;   bottom: 0;   left: 0; } .bread-btn .bread-pot:after {   content: "Pay over time";   position: absolute;   margin-top: -1px;   top: 50%;   left: 50%;   width: 100%;   margin-left: -10px;   -webkit-transform: translate3d(-50%, -50%, 0); }  .bread-center {   text-align: center;   vertical-align: middle;   height: 100%;   width: 100%;   display: table; }  .bread-center-inner {   display: table-cell;   vertical-align: middle; }  .bread-label {   color: #000; }  .bread-label {   text-align: center;   border: 1px solid #dd0000;   border-width: 1px 0;   font-size: 12px;   letter-spacing: 1px; } .bread-label .bread-embed-inner {   display: inline-block;   vertical-align: middle;   height: 100%; } .bread-label .bread-embed-icon {   position: absolute;   top: 0;   right: 2px;   background: #dd0000;   width: 2em;   height: 1.75em;   border-radius: 0 0 9999px 9999px;   color: #fff;   line-height: 1.75em;   font-size: 1.1em;   font-family: serif;   font-style: italic;   font-weight: bold;   box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3); } .bread-label .bread-embed-icon:after {   content: "i"; }
**Title**|[Text]|The text that is displayed for the Bread payment option at checkout|Bread: Pay over time
**Incomplete Bread Checkout error**|[Text]|The text displayed to the user if she attempts to move past the payment section of checkout when Bread is selected but the Bread checkout flow has not been successfully completed|Please click the pay over time button and complete the Bread finance forms or choose another payment method.
**New Order Authorize**|[Yes/No]|When set to yes, automatically authorize any successful orders to ensure that Bread will guarantee payment for the full order amount.  If this is set to No, you must authorize orders yourself|Yes

###Extending
The Bread Magento Extension includes everything you need to get started.  Some merchants, however, may wish to alter the Bread extension code to integrate Bread more tightly with their custom Magento storefront.  For instance, a merchant may want to include logic to show the Bread button on only certain product categories or products of minimum prices, or to display the button on each product of a category page. Merchants should feel free to alter the code as they like.

The Bread Magento Extension is open source under the MIT License, and Bread will be making it available on Github for forking and contribution.  Bread is interested in hearing what you'd like to see in the extension and is grateful for your contribution.

The code for the Magento checkout extension is found in the following locations under your Magento install folder: 
- ```app\code\community\Bread\BreadCheckout\block``` - Contains the code for the various blocks that Bread places on Magento pages.  Form.php defines the checkout payment option block.  View.php defines the product detail view Bread button block.  Overview.php extends View.php and defines the shopping cart overview Bread button block
- ```app\code\community\Bread\BreadCheckout\controllers``` - ProductPageCheckoutController.php defines the web services that enable checkout with Bread from anywhere in your site, including callback hooks into your store's tax and shipping logic
- ```app\code\community\Bread\BreadCheckout\etc``` - Contains xml configuration files specifying the various blocks and the configuration options in the Magento admin panel
- ```app\code\community\Bread\BreadCheckout\model``` - Contains classes that implement Bread as a Magento payment method
- ```app\design\frontend\base\default\layout\breadcheckout.xml``` - A configuration file specifying where to place Bread button blocks
- ```app\design\frontend\base\default\template\breadcheckout``` - Contain templates that define the HTML and javascript output of the Bread blocks

### Support
For any questions or comments, please email eng@getbread.com.