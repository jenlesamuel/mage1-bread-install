<?php
/**
 * Class Bread_BreadCheckout_AdminBreadOrderController
 *
 * @author  Bread   copyright 2016
 * @author  Joel    @Mediotype
 */
class Bread_BreadCheckout_Adminhtml_BreadController extends Mage_Adminhtml_Controller_Action
{
    /**
     * Post cart to backend
     */
    public function sendMailAction()
    {
        $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();

        $url = $this->getRequest()->getParam('url');

        $ret = array(
            'error' => false,
            'successRows' => array(),
            'errorRows' => array(),
        );
        try{
            Mage::helper('breadcheckout/customer')->sendCartActivationEmailToCustomer(
                $quote->getCustomer(),
                $url,
                Mage::helper('breadcheckout/quote')->getQuoteItemsData()
            );
            $ret['successRows'][] = $this->__('A Bread Cart email was successfully sent to the customer.');
        }catch (Exception $e){
            $ret['error'] = true;
            $ret['errorRows'][] = $this->__('An error occurred while sending email:');
            $ret['errorRows'][] = $e->getMessage();
        }

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($ret));
    }

    /**
     * Send cart activation sms
     */
    public function sendSmsAction()
    {
        $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();

        $id = $this->getRequest()->getParam('id');

        $ret = array(
            'error' => false,
            'successRows' => array(),
            'errorRows' => array(),
        );
        try{
            Mage::helper('breadcheckout/customer')->sendCartActivationSmsToCustomer($quote, $id);
            $ret['successRows'][] = $this->__('A Bread Cart SMS was successfully sent to the customer.');
        }catch (Exception $e){
            $ret['error'] = true;
            $ret['errorRows'][] = $this->__('An error occurred while sending SMS:');
            $ret['errorRows'][] = $e->getMessage();
        }

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($ret));
    }

    /**
     * Send cart activation email
     */
    public function sendBreadMailAction()
    {
        $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();

        $id = $this->getRequest()->getParam('id');

        $ret = array(
            'error' => false,
            'successRows' => array(),
            'errorRows' => array(),
        );
        try{
            Mage::helper('breadcheckout/customer')->sendCartActivationBreadEmailToCustomer($quote, $id);
            $ret['successRows'][] = $this->__('A Bread Cart email was successfully sent to the customer.');
        }catch (Exception $e){
            $ret['error'] = true;
            $ret['errorRows'][] = $this->__('An error occurred while sending email:');
            $ret['errorRows'][] = $e->getMessage();
        }

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($ret));
    }

    /**
     * Post cart to backend
     */
    public function createCartAction()
    {
        try {
            $ret = array(
                     'error'       => false,
                     'successRows' => array(),
                     'errorRows'   => array(),
                     'cartUrl'     => ''
            );

            $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();

            if (!$quote || ($quote && $quote->getItemsQty() == 0)) {
                Mage::throwException('Cart is empty');
            }

            if ($quote->getPayment()->getMethodInstance()->getCode()
                != Mage::getModel('breadcheckout/payment_method_bread')->getMethodCode()) {
                Mage::throwException('In order to checkout with bread you must choose bread as payment option.');
            }

            $arr = array();

            $arr['expiration'] = Mage::getModel('core/date')
                ->date('Y-m-d', strtotime('+' . Mage::getStoreConfig('checkout/cart/delete_quote_after') . 'days'));
            $arr['options'] = array();
            $arr['options']['orderRef'] = $quote->getId();
            $arr['options']['completeUrl'] = Mage::helper('breadcheckout')->getLandingPageURL();
            $arr['options']['errorUrl'] = Mage::helper('breadcheckout')->getLandingPageURL(true);

            $arr['options']['shippingOptions'] = array();

            $method = $quote->getShippingAddress()->getShippingMethod();

            if (!$method) {
                Mage::throwException('Please specify a shipping method.');
            }

            foreach ($quote->getShippingAddress()->collectShippingRates()->getGroupedAllShippingRates() as $rate) {
                foreach ($rate as $r) {
                    if ($r['code'] == $method) {
                        array_push(
                            $arr['options']['shippingOptions'],
                            array(
                                'type'   => $r['carrier_title'] . ' - ' . $r['method_title'],
                                'typeId' => $method,
                                'cost'   => Mage::helper('breadcheckout')->getCentsFromPrice($r['price'])
                            )
                        );
                    }
                }
            }

            $arr['options']['shippingContact'] = $this->parseAddress($quote->getShippingAddress());
            if (!$arr['options']['shippingContact']['email']){
                $arr['options']['shippingContact']['email'] = $quote->getCustomerEmail();
            }

            $arr['options']['billingContact']  = $this->parseAddress($quote->getBillingAddress());
            if (!$arr['options']['billingContact']['email']){
                $arr['options']['billingContact']['email'] = $quote->getCustomerEmail();
            }

            if(!Mage::helper('breadcheckout')->isHealthcare() && !$quote->getUseRewardPoints()){
                $arr['options']['items'] = Mage::helper('breadcheckout/quote')->getQuoteItemsData();
            } else {
                $arr['options']['customTotal'] = Mage::helper('breadcheckout')->getCentsFromPrice($quote->getGrandTotal());
            }

            $arr['options']['discounts'] = array();
            $totals = $quote->getTotals();

            if ($totals && isset($totals['discount'])) {
                $discountAmount = Mage::helper('breadcheckout')
                    ->getCentsFromPrice(abs($quote->getTotals()['discount']->getValue()));

                if ($discountAmount > 0) {
                    array_push(
                        $arr['options']['discounts'],
                        array(
                            'amount'      => $discountAmount,
                            'description' => $this->__('Cart Discount')
                        )
                    );
                }
            } else if ($totals && $quote->getUseRewardPoints()){
                array_push($arr['options']['discounts'],
                array(
                    'amount' => round($quote->getRewardCurrencyAmount() * 100),
                    'description' => $this->__('Reward Points')
                ));
            }

            $tax = Mage::helper('breadcheckout')
                ->getCentsFromPrice($quote->getShippingAddress()->getData('tax_amount'));

            if ($tax) {
                $arr['options']['tax'] = $tax;
            }

            if (Mage::helper('breadcheckout')->isTargetedFinancing() && Mage::helper('breadcheckout')->checkFinancingMode('cart')) {
                $financingId = Mage::helper('breadcheckout')->getFinancingId();
                $threshold = Mage::helper('breadcheckout')->getTargetedFinancingThreshold();
                $arr['options']['financingProgramId'] = $quote->getGrandTotal() >= $threshold ? $financingId : null;
            } elseif (Mage::helper('breadcheckout')->isTargetedFinancing() && Mage::helper('breadcheckout')->checkFinancingMode('sku')
                    && Mage::helper('breadcheckout/quote')->isFinancingBySku()) {
                $arr['options']['financingProgramId'] = Mage::helper('breadcheckout')->getFinancingId();
            }

            $result = Mage::getModel('breadcheckout/payment_api_client')->submitCartData($arr);

            $ret['successRows'] = array(
                $this->__(
                    'A Bread Cart was created successfully. Send the following link to your 
                    customer or trigger an email or sms to the customer.'
                ),
                sprintf('<a href="%1$s">%1$s</a>', $result->url)
            );

            $ret['cartUrl'] = $result->url;
            $ret['cartId'] = $result->id;
        }catch (Exception $e){
            $ret['error'] = true;
            $ret['errorRows'][] = $this->__('There was an error in cart creation:');
            $ret['errorRows'][] = $e->getMessage();
        }

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($ret));
    }

    /**
     * Parse address to array
     *
     * @param $address
     * @return array
     */
    protected function parseAddress($address)
    {
        $contactMap = array(
            'firstName' => 'firstname',
            'lastName'  => 'lastname',
            'email'     => 'email',
            'address'   => 'street',
            'address2'  => '',
            'city'      => 'city',
            'state'     => 'region',
            'zip'       => 'postcode',
            'phone'     => 'telephone'
        );
        $arr = array();
        foreach ($contactMap as $k=>$v) {
            $arr[$k] = $address[$v];
        }

        $arr['address2']='';
        $states = Mage::getModel('directory/country')->load($address['country_id'])->getRegions();
        foreach ($states as $state) {
            if ($state['default_name'] == $arr['state']) {
                $arr['state'] = $state['code'];
            }
        }

        return $arr;
    }

    /**
     * Validate Payment Method In Admin
     */
    public function validatePaymentMethodAction()
    {
        $result     = false;

        try {
            $token      = $this->getRequest()->getParam('token');
            if ($token) {
                $data   = Mage::getModel('breadcheckout/payment_api_client')->getInfo($token);
                if (isset($data->breadTransactionId)) {
                    Mage::getSingleton('checkout/session')->setBreadTransactionId($data->breadTransactionId);
                    $result     = true;
                }
            }
        } catch (Exception $e) {
            Mage::helper('breadcheckout')
                ->log(
                    array('EXCEPTION IN VALIDATE PAYMENT IN ADMIN CONTROLLER'=>$e->getMessage()),
                    'bread-exception.log'
                );
            Mage::logException($e);
            Mage::throwException($e);
        }

        $this->getResponse()->setBody(
            Mage::helper('core')->jsonEncode(
                array(
                'result' => $result,
                )
            )
        );
    }

    /**
     * Check is allowed access to action
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        if (!Mage::getSingleton('admin/session')->isAllowed('bread_checkout')) {
            return false;
        }

        return true;
    }


    /**
     * Endpoint for admin section apie keys validation
     */
    public function validateApiKeysAction()
    {

        $apiMode = $this->getRequest()->getParam('apiMode');
        $username = $this->getRequest()->getParam('pubKey');
        $password = $this->getRequest()->getParam('secKey');

        $result = $this->testCredentials($apiMode,$username,$password);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(
            Mage::helper('core')->jsonEncode($result)
        );
    }

    /**
     * Tests api credentials by trying to create carts
     *
     * @param $apiMode
     * @param $username
     * @param $password
     * @return bool
     */
    private function testCredentials($apiMode,$username,$password)
    {
        $dummy = [];
        $dummy['options'] = [];
        $dummy['expiration'] = date('Y-m-d');
        $dummy['options']['cartName'] = 'API Key Validation';
        $dummy['options']['customTotal'] = 10000;
        $url = (bool)$apiMode ? Bread_BreadCheckout_Helper_Data::API_LIVE_URI : Bread_BreadCheckout_Helper_Data::API_SANDBOX_URI;
        $url .= 'carts/';

        try {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_USERPWD, $username . ':' . $password);
            curl_setopt($curl, CURLOPT_TIMEOUT, 30);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen(json_encode($dummy))]);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($dummy));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($curl);
            $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);
            if ($status != 200) {
                Mage::helper('breadcheckout')->log('Failed keys validation');
                return false;
            } else {
                return true;
            }
        } catch (\Exception $e) {
            Mage::helper('breadcheckout')->log([
                'STATUS'    => 'BACKEND API KEYS TEST',
                'RESULT'    => $result
            ]);
            curl_close($curl);
        }
    }
}
