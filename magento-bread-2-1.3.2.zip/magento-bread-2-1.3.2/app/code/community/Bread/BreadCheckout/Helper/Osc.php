<?php

/**
 * Class Bread_BreadCheckout_Helper_Osc
 */
class Bread_BreadCheckout_Helper_Osc extends Bread_BreadCheckout_Helper_Data
{
    const XML_CONFIG_BREAD_REDIRECT = 'payment/bread_checkout/redirect';
    const XML_CONFIG_BREAD_IS_OSC   = 'payment/bread_checkout/is_osc';

    /**
     * Check if create carts redirect is turned on for checkout page
     *
     * @param null $store
     * @return mixed
     */
    public function getRedirectToBread($store = null)
    {
        return (bool) Mage::getStoreConfig(self::XML_CONFIG_BREAD_REDIRECT, $store);
    }

    /**
     * Is one step checkout mode enabled
     */
    public function getIsOsc($store = null)
    {
        return (bool)Mage::getStoreConfig(self::XML_CONFIG_BREAD_IS_OSC, $store);
    }

    /**
     * Create bread cart, returns bread cart url if successful
     *
     * @return string|bool
     */
    public function createOscCart()
    {
        try {
            $redirectUrl = false;

            /** @var Mage_Sales_Model_Quote $quote */
            $quote  = Mage::helper('breadcheckout/quote')->getSessionQuote();

            $arr = array();

            $arr['expiration'] = Mage::getModel('core/date')
                ->date('Y-m-d', strtotime('+' . Mage::getStoreConfig('checkout/cart/delete_quote_after') . 'days'));
            $arr['options'] = array();
            $arr['options']['orderRef'] = $quote->getId();

            $isSecure = Mage::app()->getFrontController()->getRequest()->isSecure();
            $coreUrl = Mage::getModel('core/url');

            $completeUrl = Mage::getUrl('bread/bread/cartRedirect', array('_secure'=>$isSecure));
            $completeUrl = $coreUrl->sessionUrlVar($completeUrl);
            $errorUrl = Mage::getUrl('bread/bread/cartRedirect', array(
                '_query' => array(
                    'error' => true,
                    'checkoutUrl' => Mage::helper('checkout/url')->getCheckoutUrl()
                ),
                '_secure'=>$isSecure));
            $errorUrl = $coreUrl->sessionUrlVar($errorUrl);

            $arr['options']['completeUrl'] = $completeUrl;
            $arr['options']['errorUrl'] = $errorUrl;
            $arr['options']['disableEditShipping'] = true;

            $arr['options']['shippingOptions'] = array();

            $method = $quote->getShippingAddress()->getShippingMethod();

            foreach ($quote->getShippingAddress()->collectShippingRates()->getGroupedAllShippingRates() as $rate) {
                foreach ($rate as $r) {
                    if ($r['code'] == $method) {
                        array_push(
                            $arr['options']['shippingOptions'],
                            array(
                                'type'   => $r['carrier_title'] . ' - ' . $r['method_title'],
                                'typeId' => $method,
                                'cost'   => $this->getCentsFromPrice($r['price'])
                            )
                        );
                    }
                }
            }


            $arr['options']['shippingContact'] = $this->parseAddress($quote->getShippingAddress());
            if (!$arr['options']['shippingContact']['email']){
                $arr['options']['shippingContact']['email'] = $quote->getCustomerEmail();
            }

            $arr['options']['billingContact']  = $this->parseAddress($quote->getBillingAddress());
            if (!$arr['options']['billingContact']['email']){
                $arr['options']['billingContact']['email'] = $quote->getCustomerEmail();
            }

            $arr['options']['items'] = array();
            foreach ($quote->getAllVisibleItems() as $item) {
                array_push($arr['options']['items'], $this->parseItem($item));
            }

            $arr['options']['customTotal'] = $this->getCentsFromPrice($quote->getGrandTotal());

            if($this->isTargetedFinancing() && $this->checkFinancingMode('cart')){

                $financingId = $this->getFinancingId();
                $threshold = $this->getTargetedFinancingThreshold();
                $arr['options']['financingProgramId'] = $quote->getGrandTotal() >= $threshold ? $financingId : null;

            } elseif ($this->isTargetedFinancing() && $this->checkFinancingMode('sku')){

                $isAllowed = Mage::helper('breadcheckout/quote')->isFinancingBySku();

                if($isAllowed){
                    $arr['options']['financingProgramId'] = $this->getFinancingId();
                }

            }

            $arr['options']['discounts'] = array();
            $totals = $quote->getTotals();

            if ($totals && isset($totals['discount'])) {
                array_push(
                    $arr['options']['discounts'],
                    array(
                        'amount'      => $this->getCentsFromPrice(
                            abs($quote->getTotals()['discount']->getValue())
                        ),
                        'description' => $this->__('Cart Discount')
                    )
                );
            }

            $tax = $this->getCentsFromPrice($quote->getShippingAddress()->getData('tax_amount'));

            if ($tax) {
                $arr['options']['tax'] = $tax;
            }

            $result = Mage::getModel('breadcheckout/payment_api_client')->submitCartData($arr);

            $this->log(array(
                'CREATE OSC CART' => $result
            ));

            $redirectUrl = $result->url;
        }catch (Exception $e){
            $this->log($e->getMessage());
        }

        return $redirectUrl;

    }

    /**
     * Parse quote item to array
     *
     * @param item
     * @return array
     */
    protected function parseItem($item)
    {
        $sku = $item->getProduct()['sku'];
        if ($item->getBuyRequest()->getOptions()) {
            foreach ($item->getBuyRequest()->getOptions() as $code => $option) {
                foreach ($item->getProduct()->getOptions() as $_option) {
                    if ($code == $_option->getOptionId()) {
                        $opt = $_option;
                    }
                }

                if (!empty($opt)) {
                    switch ($opt->getType()) {
                        case 'area':
                        case 'field':
                            $title = $opt->getSku();
                            $value = $option;
                            break;
                        case 'multiple':
                        case 'checkbox':
                            foreach ($option as $o) {
                                foreach ($opt->getValues() as $k => $v) {
                                    if ($k == $o) {
                                        $value = $v->getSku();
                                    }
                                }

                                $sku .= '***' . $value;
                            }

                            $value = null;
                            break;
                        case 'drop_down':
                        case 'radio':
                            $title = null;
                            foreach ($opt->getValues() as $k => $v) {
                                if ($k == $option) {
                                    $value = $v->getSku();
                                }
                            }
                            break;
                        case 'date_time':
                        case 'time':
                        case 'date':
                            $title = $opt->getSku();
                            $value = $option['date_internal'];
                            break;
                        case 'file':
                            $title = $opt->getSku();
                            $value = json_encode($option);
                            break;
                    }

                    if ($title && $value) {
                        $sku .= '***' . $title . '===' . $value;
                    } else if ($value) {
                        $sku .= '***' . $value;
                    }

                    $title = null;
                    $value = null;
                } else {
                    $this->log(array(
                        'ERROR PARSING ITEM WITH OPTION $_option ' => $_option ? $_option->getData() : 'IS NULL'
                    ));
                }
            }
        }

        $image = $item->getProduct()->getSmallImage();
        if(!$image)
            $image = '/placeholder/' .Mage::getStoreConfig('catalog/placeholder/small_image_placeholder');
        return array(
            'imageUrl'  => $this->getMediaPath($image),
            'detailUrl' => $item->getProduct()->getProductUrl(),
            'name'      => $item->getProduct()->getName(),
            'price'     => $this->getCentsFromPrice($item->getPrice()),
            'quantity'  => $item['qty'],
            'sku'       => $sku
        );
    }

    /**
     * Parse address to array
     *
     * @param $address Mage_Sales_Model_Quote_Address
     * @return array
     */
    protected function parseAddress($address)
    {
        $contactMap = array(
            'firstName' => 'firstname',
            'lastName'  => 'lastname',
            'email'     => 'email',
            'address'   => 'street',
            'address2'  => '',
            'city'      => 'city',
            'state'     => 'region',
            'zip'       => 'postcode',
            'phone'     => 'telephone'
        );
        $arr = array();
        foreach ($contactMap as $k=>$v) {
            $arr[$k] = $address[$v];
        }

        $arr['address2']='';
        $states = Mage::getModel('directory/country')->load($address['country_id'])->getRegions();
        foreach ($states as $state) {
            if ($state['default_name'] == $arr['state']) {
                $arr['state'] = $state['code'];
            }
        }

        return $arr;
    }
}
