<?php
/**
 * Handles Product View Block
 *
 * @copyright   Bread   2016
 * @author      Joel    @Mediotype
 */
class Bread_BreadCheckout_Block_Product_View extends Mage_Core_Block_Template
{

    protected $_product;

    protected function _construct()
    {
        $this->setBlockCode($this->getBlockCode());
        if ($this->getBlockCode() === Bread_BreadCheckout_Helper_Data::BLOCK_CODE_PRODUCT_VIEW) {
            $this->setAdditionalData(
                array(
                    'product_id' => $this->getProduct()->getId()
                )
            );
        }

        parent::_construct();
    }

    /**
     * Get Current Product
     *
     * @return Mage_Catalog_Model_Product
     */
    public function getProduct()
    {
        if (null === $this->_product) {
            $this->_product = Mage::registry('product');
        }

        return $this->_product;
    }

    /**
     * Get Product Data as JSON
     *
     * @return string
     */
    public function getProductDataJson()
    {
        $product = $this->getProduct();
        $data = array(
            $this->helper('breadcheckout/catalog')->getProductDataArray($product, null)
        );

        return $this->helper('core')->jsonEncode($data);
    }

    /**
     * Returns empty values so that the page can work the same as the cart page.
     *
     * @return string
     */
    public function getDiscountDataJson()
    {
        $result = array();
        return $this->helper('core')->jsonEncode($result);
    }

    /**
     * Get Default Customer Shipping Address If It Exists
     *
     * @return string
     */
    public function getShippingAddressData()
    {
        return $this->helper('breadcheckout/customer')->getShippingAddressData();
    }

    /**
     * Get Billing Address Default Data
     *
     * @return string
     */
    public function getBillingAddressData()
    {
        return $this->helper('breadcheckout/customer')->getBillingAddressData();
    }

    /**
     * Get As Low As Option Value
     *
     * @return string
     */
    protected function getAsLowAs()
    {
        return ($this->helper('breadcheckout')->isAsLowAsPDP()) ? 'true' : 'false';
    }

    /**
     * Use new window instead of modal
     *
     * @return bool
     */
    public function getShowInWindow()
    {
        return ($this->helper('breadcheckout')->getShowInWindowPDP()) ? 'true' : 'false';
    }

    /**
     * Checks Settings For Show On Product Detail Page During Output
     *
     * @return string
     */
    protected function _toHtml()
    {
        if ($this->getBlockCode() === Bread_BreadCheckout_Helper_Data::BLOCK_CODE_PRODUCT_VIEW
            && $this->helper('breadcheckout')->isEnabledOnPDP()
            && $this->_checkThreshold()
            && !$this->helper('breadcheckout')->checkDisabledForSku($this->getProduct()->getSku())
        ){

            return parent::_toHtml();
        } elseif ($this->getBlockCode() === Bread_BreadCheckout_Helper_Data::BLOCK_CODE_CHECKOUT_OVERVIEW
            && $this->helper('breadcheckout')->isEnabledOnCOP()) {

            return parent::_toHtml();
        }

        return '';
    }

    /**
     * Validate if product price is above threshold
     *
     * @return bool
     */
    private function _checkThreshold()
    {
        $productData = $this->helper('breadcheckout/catalog')->getProductDataArray($this->getProduct(), null);
        $price = $productData['price'] / 100;

        return $this->helper('breadcheckout')->aboveThreshold($price);
    }

    /**
     * Get Shipping Estimate Url
     *
     * @return string
     */
    public function getShippingAddressEstimationUrl()
    {
        return $this->helper('breadcheckout')->getShippingEstimateUrl();
    }

    /**
     * Get Tax Estimate URL
     *
     * @return string
     */
    public function getTaxEstimationUrl()
    {
        return $this->helper('breadcheckout')->getTaxEstimateUrl();
    }

    /**
     * Get Validate Order URL
     *
     * @return string
     */
    public function getValidateOrderUrl()
    {
        return $this->helper('breadcheckout')->getValidateOrderURL();
    }

    /**
     * Get Is Button On Product
     *
     * @return string
     */
    public function getIsButtonOnProduct()
    {
        return ($this->helper('breadcheckout')->isButtonOnProducts()) ? 'true' : 'false';
    }

    /**
     * Get Default Button Size String For The View
     *
     * @return string
     */
    public function getIsDefaultSize()
    {
        return (string)$this->helper('breadcheckout/Catalog')->getDefaultButtonSizeProductDetailHtml();
    }

    /**
     * Check if checkout through Bread interaction is allowed
     *
     * @return mixed
     */
    public function getAllowCheckout()
    {
        return ($this->helper('breadcheckout')->getAllowCheckoutPDP()) ? 'true' : 'false';
    }

    /**
     * Return Block View Product Code
     *
     * @return string
     */
    public function getBlockCode()
    {
        return (string)$this->helper('breadcheckout')->getBlockCodeProductView();
    }

    /**
     * Get Extra Button Design CSS
     *
     * @return mixed
     */
    public function getButtonDesign()
    {
        return $this->helper('breadcheckout')->getButtonDesign();
    }

    /**
     * Check if Cart Size financing is enabled
     *
     * @return bool
     */
    public function isTargetedFinancing()
    {
        return $this->helper('breadcheckout')->isTargetedFinancing();
    }

    /**
     * Get financing ID associated with cart size threshold
     *
     * @return string
     */
    public function getFinancingId()
    {
        return $this->helper('breadcheckout')->getFinancingId();

    }

    /**
     * Return targeted financing mode
     *
     * @param string $mode
     * @return int
     */
    public function checkFinancingMode($mode)
    {
        return $this->helper('breadcheckout')->checkFinancingMode($mode);
    }

    /**
     * Get cart size over which targeted financing is enabled
     *
     * @return string
     */
    public function getTargetedFinancingThreshold()
    {
        return $this->helper('breadcheckout')->getTargetedFinancingThreshold();
    }

    /**
     * Get list of SKU's for which targeted financing is enabled
     *
     * @return array
     */
    public function getTargetedFinancingSkus()
    {
        return $this->helper('breadcheckout')->getTargetedFinancingSkus();
    }

    /**
     * Returns Bundle product selection
     *
     * @param $product
     * @return false|string
     */
    public function getBundleSelectionJson($product)
    {
        $collection = $product->getTypeInstance(true)->getSelectionsCollection(
            $product->getTypeInstance(true)->getOptionsIds($product), $product
        );

        $bundleSelection = [];
        foreach ($collection as $item) {
            $bundleSelection[$item->getSelectionId()] = array(
                'sku' => $item->getSku(),
                'price' => $item->getFinalPrice(),
            );
        }


        return json_encode($bundleSelection);
    }

    /**
     * Get grouped product update url
     *
     * @return string
     */
    public function getGroupedButtonUpdate()
    {
        return $this->helper('breadcheckout')->getGroupedButtonUpdateUrl();
    }
}
