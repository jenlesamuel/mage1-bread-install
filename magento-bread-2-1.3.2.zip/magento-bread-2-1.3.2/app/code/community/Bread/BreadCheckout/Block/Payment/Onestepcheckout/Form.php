<?php
/**
 * Handles Payment Form in Checkout
 *
 * @copyright   Bread   2016
 * @author      Joel    @Mediotype
 * Class Bread_BreadCheckout_Block_Payment_Onestepcheckout_Form
 */
class Bread_BreadCheckout_Block_Payment_Onestepcheckout_Form extends  Bread_BreadCheckout_Block_Payment_Form
{
    /**
     * @var $_quote Mage_Sales_Model_Quote
     */
    protected $_quote;

    public function __construct()
    {
        parent::__construct();
        if($this->isRedirect()){
            $this->setTemplate('breadcheckout/onestepcheckout/redirect.phtml');
        } else {
            $this->setTemplate('breadcheckout/onestepcheckout/form.phtml');
        }
    }

    /**
     * Get Bread Formatted Shipping Address Data
     *
     * @return string
     */
    public function getShippingAddressData()
    {
        $shippingAddress    = $this->_getQuote()->getShippingAddress();

        if ($shippingAddress->getStreet(-1) === null) {
            return 'false';
        }

        $breadAddressData   = $this->helper('breadcheckout/Quote')->getFormattedShippingAddressData($shippingAddress);

        return $this->helper('core')->jsonEncode($breadAddressData);
    }

    /**
     * Get Bread Formatted Billing Address Data
     *
     * @return string
     */
    public function getBillingAddressData()
    {
        $billingAddress     = $this->_getQuote()->getBillingAddress();

        if ($billingAddress->getStreet(-1) === null) {
            return 'false';
        }

        $breadAddressData   = $this->helper('breadcheckout/Quote')->getFormattedBillingAddressData($billingAddress);

        return $this->helper('core')->jsonEncode($breadAddressData);
    }

    /**
     * Get Tax Amount From Quote
     *
     * @return float
     */
    public function getTaxValue()
    {
        return $this->helper('breadcheckout/Quote')->getTaxValue();
    }

    /**
     * Get Grand Total From Quote
     *
     * @return mixed
     */
    public function getGrandTotal()
    {
        return $this->helper('breadcheckout/Quote')->getGrandTotal();
    }

    /**
     * Get Discount Data From Quote as JSON
     *
     * @return string
     */
    public function getDiscountDataJson()
    {
        $discountData   = $this->helper('breadcheckout/Quote')->getDiscountData();

        return $this->helper('core')->jsonEncode($discountData);
    }

    /**
     * Get Items Data From Quote As JSON
     *
     * @return string JSON String or Empty JSON Array String
     */
    public function getItemsData()
    {
        $itemsData      = $this->helper('breadcheckout/Quote')->getQuoteItemsData();

        return $this->helper('core')->jsonEncode($itemsData);
    }

    /**
     * Get Bread Formatted Shipping Options Information
     *
     * @return string
     */
    public function getShippingOptions()
    {
        $shippingAddress        = $this->_getQuote()->getShippingAddress();

        if (!$shippingAddress->getShippingMethod()) {
            return 'false';
        }

        $data   = $this->helper('breadcheckout/quote')->getFormattedShippingOptionsData($shippingAddress);

        return $this->helper('core')->jsonEncode($data);
    }

    /**
     * Get Incomplete Checkout Messaging
     *
     * @return string
     */
    public function getIncompleteCheckoutMessage()
    {
        return $this->helper('breadcheckout')->getIncompleteCheckoutMsg();
    }

    /**
     * Get Incomplete Checkout Messaging
     *
     * @return string
     */
    public function getSkipReview()
    {
        return $this->helper('breadcheckout')->skipReview();
    }

    /**
     * Add context URL based on frontend or admin
     *
     * @param $route
     * @return string
     */
    public function getContextUrl($route)
    {
        $isSecure = Mage::app()->getFrontController()->getRequest()->isSecure();
        if (Mage::app()->getStore()->isAdmin()) {
            $adminUrl = Mage::getModel('adminhtml/url')->getUrl('adminhtml/' . $route, array('_secure'=>true));
            return $adminUrl;
        } else {
            return $this->getUrl($route, array('_secure'=>true));
        }
    }

    /**
     * Is Default Size Handling
     *
     * @return string
     */
    public function getIsDefaultSize()
    {
        return $this->helper('breadcheckout/Catalog')->getDefaultButtonSizeCheckoutHtml();

    }

    /**
     * Get validate payment URL
     *
     * @return string
     */
    public function getPaymentUrl()
    {
        return $this->helper('breadcheckout')->getPaymentUrl();
    }

    /**
     * Get tx ID from Quote
     *
     * @return mixed
     */
    public function getBreadTransactionId()
    {
        return $this->_getQuote()->getBreadTransactionId();
    }

    /**
     * Get validate totals url
     * 
     * @return string
     */
    public function getValidationUrl()
    {
        return $this->helper('breadcheckout')->getPaymentUrl();
    }

    /**
     * Get Session Quote Object for Frontend or Admin
     *
     * @return Mage_Sales_Model_Quote
     */
    protected function _getQuote()
    {
        if ($this->_quote == null) {
                $this->_quote       = $this->helper('breadcheckout/Quote')->getSessionQuote();
        }

        return $this->_quote;
    }

    public function hasMethodTitle()
    {
        return true;
    }

    public function getMethodTitle()
    {
        $title = $this->getMethod()->getTitle();
        $showPerMonth = $this->helper('breadcheckout')->showPerMonthCalculation(Mage::app()->getStore()->getId());

        if($showPerMonth){
            try{
                $estimate = Mage::helper('breadcheckout/quote')->getQuoteEstimate();
                $title .= ' ' . $this->__('as low as %s/month*', $estimate);
            }catch (Exception $e){
                Mage::helper('breadcheckout')->log($e->getMessage(), 'bread-exception.log');
            }
        }

        return $title;
    }

    /**
     * Get Tooltip message to show on payment method
     *
     * @return string
     * @throws Varien_Exception
     */
    public function getMethodTooltip()
    {
        return Mage::getSingleton('checkout/session')->getTooltipTitle();
    }

    /**
     * Check if customer is redirected from one step checkout to bread cart
     *
     * @return mixed
     * @throws Mage_Core_Model_Store_Exception
     */
    public function isRedirect()
    {
        return Mage::helper('breadcheckout/osc')->getRedirectToBread(Mage::app()->getStore()->getId());
    }

    /**
     * Get Osc Vendor
     *
     * @return string
     * @throws Mage_Core_Model_Store_Exception
     */
    public function getOscVendor()
    {

        $storeId = Mage::app()->getStore()->getId();
        $vendor = '';

        if(Mage::helper('core')->isModuleEnabled('Idev_OneStepCheckout') &&
            Mage::getStoreConfig('onestepcheckout/general/rewrite_checkout_links', $storeId)){

            $vendor = 'idev';

        } else if (Mage::helper('core')->isModuleEnabled('IWD_Opc') &&
            Mage::getStoreConfig('iwd_opc/general/enable', $storeId)){

            $vendor = 'iwd';

        } else if(Mage::helper('core')->isModuleEnabled('Amasty_Scheckout') &&
            Mage::getStoreConfig('amscheckout/general/enabled', $storeId)
        ){

            $vendor = 'amasty';

        }

        return $vendor;
    }

}
