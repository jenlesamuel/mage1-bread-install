<?php
/**
 * Handles Payment Form in Checkout
 *
 * @copyright   Bread   2016
 * @author      Joel    @Mediotype
 * Class Bread_BreadCheckout_Block_Payment_Form
 */
class Bread_BreadCheckout_Block_Payment_Form extends Mage_Payment_Block_Form
{
    protected $_quote;      /** @var $_quote Mage_Sales_Model_Quote */

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('breadcheckout/form.phtml');
    }

    /**
     * Get Bread Formatted Shipping Address Data
     *
     * @return string
     */
    public function getShippingAddressData()
    {
        $shippingAddress    = $this->_getQuote()->getShippingAddress();

        if ($shippingAddress->getStreet(-1) === null) {
            return 'false';
        }

        $breadAddressData   = $this->helper('breadcheckout/quote')->getFormattedShippingAddressData($shippingAddress);

        return $this->helper('core')->jsonEncode($breadAddressData);
    }

    /**
     * Get Bread Formatted Billing Address Data
     *
     * @return string
     */
    public function getBillingAddressData()
    {
        $billingAddress     = $this->_getQuote()->getBillingAddress();

        if ($billingAddress->getStreet(-1) === null) {
            return 'false';
        }

        $breadAddressData   = $this->helper('breadcheckout/quote')->getFormattedBillingAddressData($billingAddress);

        return $this->helper('core')->jsonEncode($breadAddressData);
    }

    /**
     * Get Tax Amount From Quote
     *
     * @return float
     */
    public function getTaxValue()
    {
        return $this->helper('breadcheckout/quote')->getTaxValue();
    }

    /**
     * Get Grand Total From Quote
     *
     * @return mixed
     */
    public function getGrandTotal()
    {
        return $this->helper('breadcheckout/quote')->getGrandTotal();
    }

    /**
     * Get Discount Data From Quote as JSON
     *
     * @return string
     */
    public function getDiscountDataJson()
    {
        $discountData   = $this->helper('breadcheckout/quote')->getDiscountData();

        return $this->helper('core')->jsonEncode($discountData);
    }

    /**
     * Get Items Data From Quote As JSON
     *
     * @return string JSON String or Empty JSON Array String
     */
    public function getItemsData()
    {
        $itemsData      = $this->helper('breadcheckout/quote')->getQuoteItemsData();

        return $this->helper('core')->jsonEncode($itemsData);
    }

    /**
     * Get Bread Formatted Shipping Options Information
     *
     * @return string
     */
    public function getShippingOptions()
    {
        $shippingAddress        = $this->_getQuote()->getShippingAddress();

        if (!$shippingAddress->getShippingMethod()) {
            return 'false';
        }

        $data   = $this->helper('breadcheckout/quote')->getFormattedShippingOptionsData($shippingAddress);

        return $this->helper('core')->jsonEncode($data);
    }

    /**
     * Get Incomplete Checkout Messaging
     *
     * @return string
     */
    public function getIncompleteCheckoutMessage()
    {
        return $this->helper('breadcheckout')->getIncompleteCheckoutMsg();
    }

    /**
     * Get Incomplete Checkout Messaging
     *
     * @return string
     */
    public function getSkipReview()
    {
        return $this->helper('breadcheckout')->skipReview();
    }

    /**
     * Add context URL based on frontend or admin
     *
     * @param $route
     * @return string
     */
    public function getContextUrl($route)
    {
        $isSecure = Mage::app()->getFrontController()->getRequest()->isSecure();
        if (Mage::app()->getStore()->isAdmin()) {
            $adminUrl = Mage::getModel('adminhtml/url')->getUrl('adminhtml/' . $route, array('_secure'=>true));
            return $adminUrl;
        } else {
            return $this->getUrl($route, array('_secure'=>true));
        }
    }

    /**
     * Is Default Size Handling
     *
     * @return string
     */
    public function getIsDefaultSize()
    {
        return $this->helper('breadcheckout/catalog')->getDefaultButtonSizeCheckoutHtml();

    }

    /**
     * Get validate payment URL
     *
     * @return string
     */
    public function getPaymentUrl()
    {
        return $this->helper('breadcheckout')->getPaymentUrl();
    }

    /**
     * Get tx ID from Quote
     *
     * @return mixed
     */
    public function getBreadTransactionId()
    {
        return $this->_getQuote()->getBreadTransactionId();
    }

    /**
     * Get validate totals url
     *
     * @return string
     */
    public function getValidationUrl()
    {
        return $this->helper('breadcheckout')->getValidateTotalsUrl();
    }

    /**
     * Get Session Quote Object for Frontend or Admin
     *
     * @return Mage_Sales_Model_Quote
     */
    protected function _getQuote()
    {
        if ($this->_quote == null) {
            $this->_quote       = $this->helper('breadcheckout/quote')->getSessionQuote();
        }

        return $this->_quote;
    }

    /**
     * Check if Cart Size financing is enabled
     *
     * @return bool
     */
    public function isTargetedFinancing()
    {
        return $this->helper('breadcheckout')->isTargetedFinancing();
    }

    /**
     * Get financing ID associated with cart size threshold
     *
     * @return string
     */
    public function getFinancingId()
    {
        return $this->helper('breadcheckout')->getFinancingId();

    }

    /**
     * Return targeted financing mode
     *
     * @param string $mode
     * @return int
     */
    public function checkFinancingMode($mode)
    {
        return $this->helper('breadcheckout')->checkFinancingMode($mode);
    }

    /**
     * Get cart size over which targeted financing is enabled
     *
     * @return string
     */
    public function getTargetedFinancingThreshold()
    {
        return $this->helper('breadcheckout')->getTargetedFinancingThreshold();
    }

    /**
     * Get list of SKU's for which targeted financing is enabled
     *
     * @return array
     */
    public function getTargetedFinancingSkus()
    {
        return $this->helper('breadcheckout')->getTargetedFinancingSkus();
    }

    /**
     * Check if Embedded Checkout is enabled
     *
     * @return bool
     */
    public function isEmbeddedCheckout()
    {
        return $this->helper('breadcheckout')->isEmbeddedCheckout();
    }

    public function hasMethodTitle()
    {
        return true;
    }

    public function getMethodTitle()
    {
        $title = $this->getMethod()->getTitle();
        $showPerMonth = $this->helper('breadcheckout')->showPerMonthCalculation(Mage::app()->getStore()->getId());

        if($showPerMonth){
            try{
                $estimate = Mage::helper('breadcheckout/quote')->getQuoteEstimate();
                $title .= ' ' . $this->__('as low as %s/month*', $estimate);
            }catch(Exception $e){
                Mage::helper('breadcheckout')->log($e->getMessage(), 'bread-exception.log');
            }
        }

        return $title;
    }

    /**
     * Get Tooltip message to show on payment method
     *
     * @return string
     * @throws Varien_Exception
     */
    public function getMethodTooltip()
    {
        return Mage::getSingleton('checkout/session')->getTooltipTitle();
    }

}