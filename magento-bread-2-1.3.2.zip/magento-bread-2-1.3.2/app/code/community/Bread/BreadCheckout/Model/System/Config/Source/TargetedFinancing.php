<?php

class Bread_BreadCheckout_Model_System_Config_Source_TargetedFinancing
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return array(
            array('value' => 0, 'label'=>Mage::helper('breadcheckout')->__('No')),
            array('value' => 1, 'label'=>Mage::helper('breadcheckout')->__('By Cart Size')),
            array('value' => 2, 'label'=>Mage::helper('breadcheckout')->__('By SKU List')),
        );
    }


}