<?php
/**
 * Bread setup
 *
 * @author Bread   copyright   2017
 */
class Bread_BreadCheckout_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup
{
}
