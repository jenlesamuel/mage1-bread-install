<?php
/**
 *
 * @author  Bread   copyright   2017
 */
class Bread_BreadCheckout_Model_Observer
{

    /**
     * Insert Bread button on category page
     *
     * @param $observer
     */
    public function insertBreadButton($observer)
    {
        if (!Mage::helper('breadcheckout')->isEnabledOnCAT()) {
            return;
        }

        $category = Mage::registry('current_category');
        $product  = Mage::registry('product');
        if ($category && $category->getId() && empty($product)) {
            if (Mage::helper('breadcheckout/catalog')->isBreadOnCategory($category)) {
                $_block = $observer->getBlock();
                $_type = $_block->getType();
                if ($_type == 'catalog/product_price' || $_type == 'bundle/catalog_product_price') {
                    $_child = clone $_block;
                    $_child->setType('price/block');
                    $_block->setChild('child', $_child);
                    $_block->setTemplate('breadcheckout/list_product.phtml');
                }
            }
        }
    }

    /**
     * Dispatches order tracking details when order shippment is created
     *
     * @param $observer
     * @throws Varien_Exception
     */
    public function dispatchOrderTrackingDetails($observer)
    {
        /** @var Mage_Sales_Model_Order_Shipment_Track $shipmentTrack */
        $shipmentTrack = $observer->getDataObject();
        $order = $shipmentTrack->getShipment()->getOrder();
        $payment = $order->getPayment();
        $breadcheckoutCode = Mage::getModel('breadcheckout/payment_method_bread')->getMethodCode();

        /* prevent triggering for completed orders if done outside of regular processes */
        if($order->getStatus() === Mage_Sales_Model_Order::STATE_COMPLETE
            && $order->getStatus() === Mage_Sales_Model_Order::STATE_COMPLETE){
            return;
        }

        /* at the moment only first shipment data is sent */
        if(count($order->getShipmentsCollection()) > 1){
            return;
        }

        if(Mage::helper('breadcheckout')->dispatchShipmentData() && ($payment->getMethod() === $breadcheckoutCode)){
            $trackingNumber = $shipmentTrack->getNumber();
            $carrierCode = $shipmentTrack->getCarrierCode();
            if($carrierCode === 'custom' && $shipmentTrack->getTitle() !== ''){
                $carrierCode = $shipmentTrack->getTitle();
            }
            $additionalData = json_decode($payment->getAdditionalData(),true);
            $transactionId = $additionalData['transaction_id'];

            try {

                $data = Mage::getModel('breadcheckout/payment_api_client')->setShippingDetails(
                    $transactionId,
                    $trackingNumber,
                    $carrierCode
                );
                Mage::helper('breadcheckout')->log(
                    array(
                        'DISPATCH SHIPPING DETAILS'      => $data,
                    )
                );

            } catch (Exception $e){
                Mage::logException($e);
            }
        }
    }
}
